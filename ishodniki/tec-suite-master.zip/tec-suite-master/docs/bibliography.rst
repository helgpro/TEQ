############
Bibliography
############

.. [RNX] `The Receiver Independent Exchange Format`__.

.. __: http://kb.igs.org/hc/en-us/articles/201096516-IGS-Formats

.. [CRNX] Hatanaka, Y.,
	  `A Compression Format and Tools for GNSS Observation Data`__,
	  Bulletin of the GSI, V. 55, pp. 21-30, 2008.

.. __: http://www.gsi.go.jp/common/000045517.pdf
