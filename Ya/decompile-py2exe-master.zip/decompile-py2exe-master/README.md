## Introduction

# decompile-py2exe

Decompile py2exe Python 3 generated EXEs

## Requirements

- pefile (can be installed with pip)
- uncompyle6 (can be installed with pip)

## About decompile-py2exe

decompile-py2exe is developed by Didier Stevens.

